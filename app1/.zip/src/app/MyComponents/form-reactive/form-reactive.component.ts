import { feebback } from './../../shared/feedbackform';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-form-reactive',
  templateUrl: './form-reactive.component.html',
  styleUrls: ['./form-reactive.component.scss']
})
export class FormReactiveComponent implements OnInit {

  FeedBack: feebback| any;

  constructor(
    private fb:FormBuilder) {
      //this.createform();
     }

  ngOnInit(): void {
  }

  /*createform() {
    this.FeedBack = this.fb.group({
      firstname: ['', Validators.required],
      lastname: ['', Validators.required]

    });*/

  

}
