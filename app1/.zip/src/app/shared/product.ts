//interface for product-list

export interface product {
 id: number ,
 name: string , 
 desc: string , 
 price: number
}