//import product array 
import { product } from "./product";

//storing data here to be rendered over all the applocation

export const Product :product[] = [
        {
          id: 1,
          name: 'abcd',
          desc: 'this is abcd desc',
          price: 1000
        },
        {
          id: 2,
          name: 'good',
          desc: 'useful',
          price: 200         
        },
        {
          id: 3,
          name: 'jdioe',
          desc: 'this is nsdoih desc',
          price: 100
        }     
      

    ];