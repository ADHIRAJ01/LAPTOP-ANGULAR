import { Component, OnInit } from '@angular/core';
//import { LoginComponent } from '../login/login.component';
//import {MatDialogModule} from '@angular/material/dialog';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  constructor() { }

  
  ngOnInit(): void {
  }
//------------------------***   how to open a modal or a component using this    ***------------------------------------------------
  openLoginForm() {
    
      //make modal and pass component
    
    



  }
}
