export interface Comment {
    rating: number;
    comment: string;
    author: string;
}