export interface feebback{
    firstname: string,
    lastname: string,
    tel: number,
    email: string,
    agree: boolean,
    message: string

}